--Show the contents of the dbo.Employees table...
SELECT * FROM dbo.Employees;

--Modify the data in the table by appending an 
--exclamation mark ('!') to every FirstName
UPDATE dbo.Employees
SET FirstName = FirstName + '!';

--Show the contents of the dbo.Employees table...
SELECT * FROM dbo.Employees;

--Modify the data in the table by removing any 
--exclamation marks ('!') from every FirstName
UPDATE dbo.Employees
SET FirstName = REPLACE(FirstName,'!','');

--Show the contents of the dbo.Employees table...
SELECT * FROM dbo.Employees;
