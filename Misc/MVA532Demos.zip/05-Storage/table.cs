using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Auth;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            CloudStorageAccount account = new CloudStorageAccount(new StorageCredentials("storagemva", "/IrtDAtzQyLOrqwIAl3rOVWY6ESN7VsB2ZPhJVfjj61NONa1LKwtwgwxSecxOntw6z6ewi7d+cPi7K/VMWj5kQ=="), true);

            CloudTableClient tableClient = account.CreateCloudTableClient();

            CloudTable table = tableClient.GetTableReference("roster");
            table.CreateIfNotExists();

            ITEmployee first = new ITEmployee { PartitionKey = "IT", RowKey = "ibahena", YearsAtCompany = 7, FavoriteOS = "Linux" };
            Employee second = new Employee { PartitionKey = "HR", RowKey = "rreeves", YearsAtCompany = 12 };
            Employee third = new Employee { PartitionKey = "HR", RowKey = "rromani", YearsAtCompany = 3 };

            TableOperation insertOperation = TableOperation.InsertOrReplace(first);
            table.Execute(insertOperation);

            TableBatchOperation batchOperation = new TableBatchOperation();
            batchOperation.InsertOrReplace(second);
            batchOperation.InsertOrReplace(third);
            table.ExecuteBatch(batchOperation);

            Console.WriteLine("HR Employees\n");
            TableQuery<Employee> query = new TableQuery<Employee>().Where(
                TableQuery.GenerateFilterCondition("PartitionKey",
                QueryComparisons.Equal, "HR")
            );
            foreach (Employee hrEmployee in table.ExecuteQuery<Employee>(query))
            {
                Console.WriteLine(hrEmployee);
            }

            Console.WriteLine("\n\n\n\nIT Employee\n");
            TableOperation retrieveOperation = TableOperation.Retrieve<Employee>("IT", "ibahena");
            TableResult result = table.Execute(retrieveOperation);
            Employee itEmployee = result.Result as Employee;
            Console.WriteLine(itEmployee);
        }
    }

    public class Employee : TableEntity
    {
        public int YearsAtCompany { get; set; }

        public override string ToString()
        {
            return RowKey + "\t\t[" + YearsAtCompany + "]";
        }
    }

    public class ITEmployee : Employee
    {
        public string FavoriteOS { get; set; }
    }
}
