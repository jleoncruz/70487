﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Notifications;

namespace SendToNotificationHub
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sending Push Notification...");
            SendNotificationAsync();
            Console.WriteLine("Push Notification Sent...");
            Console.ReadLine();
        }

        private static async void SendNotificationAsync()
        {
            NotificationHubClient hub = NotificationHubClient
                .CreateClientFromConnectionString("Endpoint=sb://mva532hub-ns.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=lEm/bKBCPJFFYIa9eaYx1qk/xVGGxlVaW1v6N1Nx89Y=", "mva532hub");
            string toast = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<wp:Notification xmlns:wp=\"WPNotification\">" +
                   "<wp:Toast>" +
                        "<wp:Text1>Hello from a .NET App!</wp:Text1>" +
                   "</wp:Toast> " +
                "</wp:Notification>";
            var result = await hub.SendMpnsNativeNotificationAsync(toast);
            Console.WriteLine(result.State.ToString());
        }
    }
}
