﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;

//[assembly: PreApplicationStartMethod(typeof(Firework.RegisterHubs), "Start")]

namespace Firework
{
    public static class RegisterHubs
    {
        public static void Start()
        {
        }
    }
}