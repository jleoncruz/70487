Fireworks
=========

Play virtual fireworks with your friends together over Internet using SignalR, HTML 5, and Javascript.

This updated version is a Website instead of a Azure Cloud Service, and it uses Redis cache as SignalR backbone.
Modify the Startup.cs file and replace "[Redis cache cluster]" and "[access key]" to your Redis cache cluster connection information.
