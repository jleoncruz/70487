﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ADWeb.Models
{
    public class IssuingAuthorityKey
    {
        public string Id { get; set; }
    }

    public class Tenant
    {
        public string Id { get; set; }
    }
}